---
name: Question
about: I want to ask a question.
labels: question
---

**General Question**

<!--

Before asking a question, make sure you have:

- Searched existing questions [forum-EN](https://discuss.nebula-graph.io/) or [forum-CH](https://discuss.nebula-graph.com.cn/).
- Googled your question.
- Searched open and closed [GitHub issues](https://github.com/vesoft-inc/nebula/issues?q=is%3Aissue).
- Read the [documentation-EN](https://docs.nebula-graph.io/) or [documentation-CH](https://docs.nebula-graph.com.cn/).

-->
