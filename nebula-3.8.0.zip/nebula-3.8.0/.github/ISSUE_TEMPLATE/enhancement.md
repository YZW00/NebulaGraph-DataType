---
name: Enhancement
about: Suggest an enhancement to make the code neat or more efficient.
title: ''
labels: type/enhancement
assignees: ''
---

**Introduction**
<!-- concise introduction to problem, motivation, and overview of proposed solution -->

**Contents**
<!-- Please describe the enhancement what you want in this section -->

**Related work**
<!-- In this section you can add other related tasks to help assigner to complete the task more easily -->
