/* Copyright (c) 2019 vesoft inc. All rights reserved.
 *
 * This source code is licensed under Apache 2.0 License.
 */

#include "common/meta/IndexManager.h"

#include "common/meta/ServerBasedIndexManager.h"

namespace nebula {
namespace meta {}  // namespace meta
}  // namespace nebula
